import markdown2
import random
from django import forms
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django.core.files.storage import default_storage
from . import util

# Formulário usado na barra lateral para pesquisar títulos de entrada
class SearchForm(forms.Form):
    query = forms.CharField(label="",
        widget=forms.TextInput(attrs={'placeholder': 'Pesquisar Wiki','style': 'width:100%'}))


# Formulário usado para criar uma nova entrada / página
class NewPageForm(forms.Form):
    title = forms.CharField(label="", widget=forms.TextInput(attrs={'placeholder': 'Enter title', 'id': 'new-entry-title'}))
    data = forms.CharField(label="", widget=forms.Textarea(attrs={'id': 'new-entry'}))


# Formulário usado para editar uma entrada / página
class EditPageForm(forms.Form):
    title = forms.CharField(label="", widget=forms.TextInput(attrs={'id': 'edit-entry-title'}))
    data = forms.CharField(label="", widget=forms.Textarea(attrs={'id': 'edit-entry'}))


# Página inicial padrão, exibe a lista de entradas / páginas criadas
def index(request):
    return render(request, "encyclopedia/index.html", {"entries": util.list_entries(),"form": SearchForm()})

# Retorna a entrada do wiki. Url: (wiki / título). Erro se não existir
def entry(request, title):
    entry = util.get_entry(title)
    # Se o url especificado não estiver na lista de entrada / página, retorne a página de erro
    if entry is None:
        return render(request, "encyclopedia/error.html", {"title": title,"form": SearchForm()})
    # Leva o usuário à entrada do título. Url: (wiki / título)
    else:
        return render(request, "encyclopedia/entry.html", {
            "title": title,
            "entry": markdown2.markdown(entry),
            "entry_raw": entry,
            "form": SearchForm()
        })

# Pesquisa por entrada de wiki
def search(request):
    if request.method == "POST":
        entries_found = []  #Lista de entradas que correspondem à consulta
        entries_all = util.list_entries()  #Todas as entradas
        form = SearchForm(request.POST)  #Obtém informações do formulário
        # Verifique se os campos do formulário são válidos
        if form.is_valid():
            # Obtenha a consulta para pesquisar entradas / páginas
            query = form.cleaned_data["query"]
            # Verifique se alguma entrada / página corresponde à consulta
            # Se existir, redirecionar para a entrada / página
            for entry in entries_all:
                if query.lower() == entry.lower():
                    title = entry
                    entry = util.get_entry(title)
                    return HttpResponseRedirect(reverse("entry", args=[title]))
                # As correspondências parciais são exibidas em uma lista
                if query.lower() in entry.lower():
                    entries_found.append(entry)
            # Devolver lista de correspondências parciais
            return render(request, "encyclopedia/search.html", {
                "results": entries_found,
                "query": query,
                "form": SearchForm()
            })
    # Valores Padrão
    return render(request, "encyclopedia/search.html", {
        "results": "",
        "query": "",
        "form": SearchForm()
    })

# Crie uma nova entrada na wiki
def create(request):
    if request.method == "POST":
        new_entry = NewPageForm(request.POST) #Obtém informações do formulário
        # Verifique se os campos de entrada são válidos
        if new_entry.is_valid():
            # Extraia o título da nova entrada
            title = new_entry.cleaned_data["title"]
            data = new_entry.cleaned_data["data"]
            # Verifique se a entrada existe com título
            entries_all = util.list_entries()
            # Se a entrada existir, retorne a mesma página com o erro
            for entry in entries_all:
                if entry.lower() == title.lower():
                    return render(request, "encyclopedia/create.html", {
                        "form": SearchForm(),
                        "newPageForm": NewPageForm(),
                        "error": "Esta entrada ja existe!"
                    })
            # Adicionada marcação para o conteúdo da entrada
            new_entry_title = "# " + title
            # Uma nova linha é acrescentada para separar o título do conteúdo
            new_entry_data = "\n" + data
            # Combine o título e os dados para armazenar como conteúdo
            new_entry_content = new_entry_title + new_entry_data
            # Salva a nova entrada com o título
            util.save_entry(title, new_entry_content)
            entry = util.get_entry(title)
            # Retorna a página para a entrada recém-criada
            return render(request, "encyclopedia/entry.html", {
                "title": title,
                "entry": markdown2.markdown(entry),
                "form": SearchForm()
            })
    # Valores padrão
    return render(request, "encyclopedia/create.html", {
        "form": SearchForm(),
        "newPageForm": NewPageForm()
    })

# Editar entrada wiki
def editEntry(request, title):
    if request.method == "POST":
        # Obtenha dados para a entrada a ser editada
        entry = util.get_entry(title)
        # Exibir conteúdo na área de texto
        edit_form = EditPageForm(initial={'title': title, 'data': entry})
        # Retorna a página com formulários preenchidos com informações de entrada
        return render(request, "encyclopedia/edit.html", {
            "form": SearchForm(),
            "editPageForm": edit_form,
            "entry": entry,
            "title": title
        })

# Enviar edição wiki
def submitEditEntry(request, title):
    if request.method == "POST":
        # Extraia informações do formulário
        edit_entry = EditPageForm(request.POST)
        if edit_entry.is_valid():
            # Extraia 'dados' do formulário
            content = edit_entry.cleaned_data["data"]
            # Extraia o 'título' do formulário
            title_edit = edit_entry.cleaned_data["title"]
            # Se o título for editado, exclua o arquivo antigo
            if title_edit != title:
                filename = f"entries/{title}.md"
                if default_storage.exists(filename):
                    default_storage.delete(filename)
            # Salvar nova entrada
            util.save_entry(title_edit, content)
            # Obtenha a nova entrada
            entry = util.get_entry(title_edit)
            msg_success = "Successfully updated!"
        # Retorne a entrada editada
        return render(request, "encyclopedia/entry.html", {
            "title": title_edit,
            "entry": markdown2.markdown(entry),
            "form": SearchForm(),
            "msg_success": msg_success
        })

# Entrada aleatória do wiki
def randomEntry(request):
    # Obtenha uma lista de todas as entradas
    entries = util.list_entries()
    # Obtenha o título de uma entrada selecionada aleatoriamente
    title = random.choice(entries)
    # Obtenha o conteúdo da entrada selecionada
    entry = util.get_entry(title)
    # Retorne a página de redirecionamento da entrada
    return HttpResponseRedirect(reverse("entry", args=[title]))
